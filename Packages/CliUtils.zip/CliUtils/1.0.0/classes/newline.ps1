Class Env {
    static $NL = [Environment]::NewLine
}
