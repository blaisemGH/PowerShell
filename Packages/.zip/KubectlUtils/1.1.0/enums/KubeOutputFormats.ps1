enum KubeOutputFormats {
    custom-columns
    custom-columns-file
    go-template
    go-template-file
    json
    jsonpath
    jsonpath-as-json
    jsonpath-file
    name
    template
    templatefile
    wide
    yaml
}