enum DataTypes {
    csv
    ini
    json
    properties
    psd1
    toml
    xml
    yaml
}