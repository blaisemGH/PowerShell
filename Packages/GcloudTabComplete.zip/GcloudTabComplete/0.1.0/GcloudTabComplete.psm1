Write-Verbose 'Importing from [D:\a\1\s\GcloudTabComplete\Private]'
# .Register-GcloudAutoComplete.ps1
function Register-GcloudTabComplete {
    [CmdletBinding()]
    param ()

    $Script:GcloudParamCache = @{}

    $GcloudSB = {
        param($WordToComplete, $CommandAst, $CursorPosition)

        if ($WordToComplete -match '^--') {
            $ParentArgs = '--'
        }
        else {
            $ParentArgs = ($CommandAst.Extent.Text -replace "gcloud(.exe)?|\b$WordToComplete\b").Trim()
        }

        if ($Script:GcloudParamCache[$ParentArgs]) {
            $AutoCompletOptions = $Script:GcloudParamCache[$ParentArgs]
        }
        else {
            if ($WordToComplete -match '^--') {
                $GcloudArgs = 'help'
            }
            else {
                $GcloudArgs = $ParentArgs.split()
            }

            if ($GcloudArgs) {
                $GcloudError = & gcloud $GcloudArgs 2>&1
            }
            else {
                $GcloudError = & gcloud 2>&1
            }

            if ($WordToComplete -match '^--') {
                $AutoCompletOptions = $GcloudError -match '^\s{5}--' -replace '^\s{5}(--[\w-]+).*', '$1'
            }
            else {
                if ($PSVersionTable.PSVersion -lt '6.0.0') {
                    $GcloudError = $GcloudError[1] -split '\r\n'
                }
                $AutoCompletOptions = $GcloudError -match '^\s{6}\b' -replace '^\s{6}\b([\w-]+).*', '$1' | Sort-Object
            }

            $Script:GcloudParamCache[$ParentArgs] = $AutoCompletOptions
        }

        $AutoCompletOptions | Where-Object {$_ -like "$WordToComplete*"}
    }

    Register-ArgumentCompleter -Native -CommandName 'gcloud' -ScriptBlock $GcloudSB
}

# .O_init.ps1
Register-GcloudTabComplete

Write-Verbose 'Importing from [D:\a\1\s\GcloudTabComplete\Public]'
# .Add-GcloudToProfile.ps1
function Add-GcloudToProfile {
    <#
    .SYNOPSIS
    Add the import module command to your profile

    .DESCRIPTION
    Add the import module command to your profile

    It will be added to your current active profile if one is found. If not it will be added to
    the CurrentUserCurrentHost profile

    If your current profile is one of the AllUsers profiles but you are not running an elevated
    console then an error will be thrown

    .EXAMPLE
    Add-GcloudToProfile

    .LINK
    https://gcloudtabcomplete.readthedocs.io/en/master/functions/Add-GcloudToProfile

    .LINK
    https://github.com/sk82jack/GcloudTabComplete/blob/master/GcloudTabComplete/Public/Add-GcloudToProfile.ps1
    #>
    [CmdletBinding(SupportsShouldProcess)]
    param()

    $ProfileLocations = $profile.psobject.properties.name -ne 'Length'

    foreach ($Location in $ProfileLocations) {
        if (Test-Path $profile.$Location) {
            if ($Location -match 'AllUsers') {
                $CurrentPrincipal = [Security.Principal.WindowsPrincipal]::new([Security.Principal.WindowsIdentity]::GetCurrent())
                $IsAdmin = $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
                if (-not $IsAdmin) {
                    throw 'You must run this function in an elevated console to write to your current profile'
                }
            }
            $CurrentProfile = $profile.$Location
            break
        }
    }

    if (-not $CurrentProfile) {
        $CurrentProfile = $profile.CurrentUserCurrentHost
    }

    $ImportCommand = 'Import-Module -Name GcloudTabComplete'

    $CurrentProfileContent = Get-Content -Path $CurrentProfile
    if (-not [string]::IsNullOrEmpty($CurrentProfileContent[-1])) {
        $ImportCommand = [Environment]::NewLine + $ImportCommand
    }

    if ($PSCmdlet.ShouldProcess($CurrentProfile, "Add '$ImportCommand' to profile")) {
        Add-Content -LiteralPath $CurrentProfile -Value $ImportCommand
    }
}


