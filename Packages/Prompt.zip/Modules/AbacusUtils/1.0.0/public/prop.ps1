### Opens a property file in your text editor.
Function prop {

	[CmdletBinding()]
	Param (
	[Parameter(Mandatory = $true,position=0)]
	[ValidateSet('builddb','cluster','compare','context','daal','davinci','db','jcal','jee','log','mpeservice','notificationService','processservice','security','spark-env','spark','sqlx','web','wildfly')]$propFile
	)
	
	If ( ! ( Test-Path $PWD/custom/properties ) ) { 
		Throw 'Please cd into an ABACUS_HOME directory'
	}
	
	$propFilePath = ( 'custom/properties/' + $propFile + '.properties' )
	& $textEditorExecutable $propFilePath
}
