### Currently deprecated as it doesn't include all ports. The full script is in the helperScript.
Function updatePorts {

	Param (

		[int]
		[Parameter(mandatory=$true)]
		$newOffset
	)
	#list of relevant properties here for single ports, also exception for db.hive.url
	#Loop through list and Get-Content custom properties to replace.
	
	Get-Content .\custom\properties\ *.properties | ForEach {
        $file = $_.FullName ; ( Get-Content $file ) | ForEach {
            $line = $_
            If ( $line -notmatch "^#" -and $line -match "[:](\d\d\d\d)") {
                $foundOldPort = $line -match "(\d\d\d\d)"
                $newPort = [int]$matches[0] + $newOffset
                $line = $line -replace $matches[0], $newPort
            }
            $line
        } | Set-Content $file
    }
}