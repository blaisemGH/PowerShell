Function Replace-TableAliasPrefixesInFunctionalUnit {
	Param(
		[Parameter(ValueFromPipeline,Mandatory)]
		[string]$FunctionalUnit,
		[Parameter(Mandatory)]
		[string[]]$TableAliases,
		[Parameter(Mandatory)]
		[string]$ReplaceWithAlias
	)
	begin {
		$regexReplacePattern = $(
			Foreach ( $alias in $TableAliases ) {
				'({0}[.])' -f $alias
			}
		) -join '|'
	}
	process {		
		$unit = $FunctionalUnit -split "\n"
		$unit -replace $regexReplacePattern, "${ReplaceWithAlias}."
	}
}