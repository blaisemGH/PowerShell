### Opens either the daal or server log in your text editor. I need to fix the server log path to be dynamically set though.
Function logs {

	[CmdletBinding()]
	Param (
	[Parameter(Mandatory = $true,position=0)]
	[validateScript( {
		If ( $_ -in ('daal','server') ) {
			$True
		}
		Else {
			Throw ("The argument '{0}' is not valid.{1}{2}Please enter either 'daal' or 'server' to access the latest daal.log or server.log file.{3}{4}To access an older log, add the date as a second argument." -f $_, [Env]::NL, "`t", [Env]::NL, "`t" )
		}
	})]
	$log,
	[Parameter(position=1)]
	[String]
	[validateScript( {
		If ( $_ -match "^(\d\d\d\d|\d\d).*\d\d.*\d\d$" ) {
			$true
		}
		Else {
			Throw ("The argument '{0}' is not valid.{1}{2}Please enter the date formatted as YYMMDD or YYYYMMDD, e.g., 211231 for December 31, 2021.{3}{4}YY-MM-DD or YYYY-MM-DD are also acceptable." -f $_, [Env]::NL, "`t", [Env]::NL, "`t" )
		}
	})]
	$date
	)
	
	If ( $date -match "^\d\d\d\d.*\d\d.*\d\d$" -and $date -notmatch "\d\d\d\d-\d\d-\d\d" ) {
		$date = $date.Insert(6,'-').Insert(4,'-')
	}
	ElseIf ( $date -match "^\d\d.*\d\d.*\d\d$" -and $date -notmatch "\d\d-\d\d-\d\d" ) {
		$date = $date.Insert(4,'-').Insert(2,'-').Insert(0,'20')
	}
	
	If ( !($date) ) {
		$logFile = ( $log + '.log' )
	}
	Else {
		$logFile = ( $log + '.log.' + $date )
	}

	switch ($log) {
	
		daal {
			$daalLogDir = (Select-String -Path 'custom\properties\daal.properties' -Pattern 'daal.logs.directory' | Select-Object -ExpandProperty Line).split('=')[1].Trim()
			& $textEditorAlias $daalLogDir
		}
		
		server {
			$jbossLogDir = (Select-String -Path 'custom\properties\wildfly.properties' -Pattern "^[^#].*jboss.server.log.dir" | select-object -expandproperty line) -Replace '.*-Djboss[.]server[.]log[.]dir ?= ?([\w:/\\]+).*','$1'
			If ( $jbossLogDir ) {
				& $textEditorAlias (Join-Path $jbossLogDir server.log )
			}
			Else {
				& $textEditorAlias (Join-Path $PWD wildfly/standalone/log/server.log)
			}
		}
	
	}
}
