function Select-DaalV2Writes {
	param(
		[parameter(mandatory)]
		[string]$entity,
		[parameter(mandatory)]
		[ArgumentCompleter({
			Param( $commandName, $parameterName, $wordToComplete, $commandAst, $fakeBoundParameters )
			Get-ChildItem $wordToComplete* -Filter *daal*.log | Resolve-Path -Relative
		})]
		[Alias('logDaal')]
		[string]$path
	)
	
	$pattern = [regex]::new("^([-0-9]+ [:.0-9]+).* Wrote ([0-9]+) records into Oracle for tableName=$entity.*Duration: ([0-9.]+)", 'Compiled, CultureInvariant')
	$matchingLines = Select-String -Path $path -Pattern $pattern |
		Select-Object @{
			'label' = 'TotalRecords'
			'expression' = {$_.Matches.Groups[2].Value}
		}, @{
			'label' = 'TotalDuration'
			'expression' = {$_.Matches.Groups[3].Value}
		}, @{
			'label' = 'Timestamp'
			'expression' = {Get-Date $_.Matches.Groups[1].Value}
		}
	$countRecords, $totalRecords = $matchingLines | Measure-Object -Sum -Property TotalRecords | Foreach { $_.Count; $_.Sum }
	$minDate, $maxDate = $matchingLines | Measure-Object -Minimum -Maximum -Property TimeStamp | Foreach { $_.Minimum; $_.Maximum }

	$totalDuration = ($maxDate - $minDate).TotalSeconds

	$entities = If ( $entity -match '_\[([A-Z]+)\]$' ) {
		Foreach ( $datatype in $Matches[1].ToCharArray() ) {
			'{0}_{1}' -f ($entity -replace '_\[([A-Z]+)\]$'), $datatype.ToString()
		}
	}
	else {
		$entity
	}

	return [PSCustomObject]@{
		Entities = $entities -join ' + '
		Records = '{0:N0}' -f $totalRecords
		TotalTime = [timespan]::FromSeconds($totalDuration).ToString('h\h\ m\m\ s\.fff\s')
		NumberOfBatchWrites = $countRecords
	}
}
