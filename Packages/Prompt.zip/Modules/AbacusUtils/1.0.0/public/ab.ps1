### Substitutes bin/abacus360.cmd, e.g., PS>ab wildfly start
Function ab {

	[CmdletBinding()]
	Param (
		[Parameter(Mandatory,ValueFromRemainingArguments)]
		$Arguments
	)

	If ( ! ( Test-Path $PWD/bin/abacus360.cmd ) ) { 
		Throw 'Please cd into an ABACUS_HOME directory'
	}
	Else {
		$abacusHome = Convert-Path (PWD)
	}

	$arrArgs = $Arguments -split ' '
	$arg1	= $arrArgs[0]
	$arg2	= $arrArgs[1]

	If (	$arg1 -eq 'restart'	) {
		$stopAll	=	Start-Process -FilePath bin/abacus360.cmd -ArgumentList 'stop' -NoNewWindow -Wait -PassThru
		If ( $stopAll.exitCode -eq 0 ) {
			bin/abacus360.cmd start
		}
		Else {
			Write-Host "ERROR! Exit Code: $($stopAll.exitCode)"
		}
	}
	ElseIf ( $arg1 -in 'install','upgrade' ) {

		$command	=	@()
		If ( $arg1 -eq 'install' ) {
			$command += 'wildfly install'
		}
		$command	+=	@(
			'wildfly service uninstall'
			'wildfly configure'
			'wildfly service install'
			'wildfly start'
			'spark install'
			'daal install'
			'daal start'
		)
		If ( $arg1 -eq 'install' ) {
			$command += 'content install'
		}

		$serverLogDir	=	((sls -Pattern 'jboss[.]server[.]log[.]dir' $abacusHome/custom/properties/wildfly.properties).Line -replace ".*-Djboss[.]server[.]log[.]dir=(\w+)",'$1').split(' ')[0]
		
		If ( $serverLogDir ) {
			$command = $command -replace 'wildfly service install', "wildfly service install /logpath $serverLogDir"
		}
		$tempFile = New-TemporaryFile
		Foreach ( $cmd in $command ) {
			Write-Host ([Env]::NL + (get-date -UFormat %H:%M:%S) + ' | Beginning command: ') -NoNewLine; Write-Host "./bin/abacus360.cmd $cmd" -ForeGroundColor yellow
			
			Switch ($cmd) {
				'wildfly start' {
					$timeoutDuration = 600
				}
				'wildfly configure' {
					$timeoutDuration = 120
				}
				'spark install' {
					$timeoutDuration = 90
				}
				'daal start' {
					$timeoutDuration = 120
				}
				DEFAULT {
					$timeoutDuration = 45
				}
			}
			$timeoutStatus = $null
			$abacus360CMD = Start-Process -FilePath bin/abacus360.cmd -ArgumentList $cmd -NoNewWindow -PassThru
			$abacus360CMD | Wait-Process -Timeout $timeoutDuration -ErrorAction SilentlyContinue -ErrorVariable timeoutStatus
			If ( $timeoutStatus ) {
				Write-Host ('{0}{1} ({2} seconds){3}' -f [Environment]::NewLine, $timeoutStatus.Exception, $timeoutDuration.ToString(), [Environment]::NewLine ) -Fore Red -Back Black
				$abacus360CMD | kill
				break
			}
			$runtime = $abacus360CMD.ExitTime - $abacus360CMD.StartTime
			#### Error control currently fails, I think because of how the original script is set up but not sure. A workaround is possible.
			If ( $abacus360Cmd.exitCode -ne 0 ){
				Write-Host @"

		ERROR!
		command: bin/abacus360.cmd $cmd
		Exit Code: $($abacus360Cmd.exitCode)

"@ -ForeGroundColor red
				Remove-Item $tempFile
				break
			}
			Else {	Write-Host ( "{0}Command '{1}' completed! " -f [Env]::NL, $cmd ) -ForeGroundColor green -NoNewLine; Write-Host ('Duration: ' + $runtime.Minutes + 'm' + $runtime.Seconds + 's' )	}
		}
		Remove-Item $tempFile
	}
	Else {
		bin/abacus360.cmd $Arguments
	}
}
