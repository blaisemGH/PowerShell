Function env {
	Get-ChildItem env:
}