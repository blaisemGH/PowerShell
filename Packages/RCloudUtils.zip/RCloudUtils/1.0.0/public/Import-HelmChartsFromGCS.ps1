Function Import-HelmChartsFromGCS {
	Param (
		[string]$RootChartPath = 'C:/rcloud/helm-charts-gcs',
		[Parameter(Mandatory, ParameterSetName='custom')]
		[string]$RepoInGCS,
		[Parameter(Mandatory, ParameterSetName='custom')]
		[string]$ChartInGCS,
		[Parameter(ParameterSetName='custom')]
		[string]$LocalRepoPath = 'C:/rcloud/helm-charts-gcs',
		[Parameter(Mandatory, ParameterSetName='all')]
		[switch]$All
	)
	If ( ! (Test-Path $LocalRepoPath) ) {
		Throw "Local chart path to synchronize does not exist! Attempted path (has default value if not input): $LocalRepoPath."
	}
	If ( $All ) {
		ForEach ( $repo in Get-ChildItem $RootChartPath ) {
			$gcsRepo = $repo.Name
			ForEach ( $chart in Get-ChildItem $repo.FullName ) {
				$gcsChart = $chart.Name
				$localPath = Join-Path $RootChartPath $gcsRepo $gcsChart
				#Write-Host "gsutil -m rsync -d -r gs://$gcsRepo/$gcsChart $localPath"
				gsutil -m rsync -d -r gs://$gcsRepo/$gcsChart $localPath
			}
		}
	}
	Else {
		$repo = $RepoInGCS
		$chart = $ChartInGCS
		If ( $LocalRepoPath ) {
			$localPath = Convert-Path $LocalRepoPath
			Write-Host "gsutil -m rsync -d -r gs://$repo/$chart $localPath"
			gsutil -m rsync -d -r gs://$RepoInGCS/$ChartInGCS $LocalRepoPath
		}
		Else {
			$localPath = Join-Path $RootChartPath $repo $chart
			Write-Host "gsutil -m rsync -d -r gs://$repo/$chart $localPath"
			gsutil -m rsync -d -r gs://$repo/$chart $LocalRepoPath
		}
	}
}