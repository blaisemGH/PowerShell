Function Import-HelmChartsFromGCS {
	Param (
		[string]$rootChartPath = 'C:/rcloud/helm-charts-gcs',
		[Parameter(Mandatory, ParameterSetName='custom')]
		[string]$repoInGCS,
		[Parameter(Mandatory, ParameterSetName='custom')]
		[string]$chartInGCS,
		[Parameter(ParameterSetName='custom')]
		[string]$localRepoPath = 'C:/rcloud/helm-charts-gcs',
		[Parameter(Mandatory, ParameterSetName='all')]
		[switch]$all
	)
	If ( ! (Test-Path $localRepoPath) ) {
		Throw "Local chart path to synchronize does not exist! Attempted path (has default value if not input): $localRepoPath."
	}
	If ( $all ) {
		ForEach ( $repo in Get-ChildItem $rootChartPath ) {
			$gcsRepo = $repo.Name
			ForEach ( $chart in Get-ChildItem $repo.FullName ) {
				$gcsChart = $chart.Name
				$localPath = Join-Path $rootChartPath $gcsRepo $gcsChart
				#Write-Host "gsutil -m rsync -d -r gs://$gcsRepo/$gcsChart $localPath"
				gsutil -m rsync -d -r gs://$gcsRepo/$gcsChart $localPath
			}
		}
	}
	Else {
		$repo = $repoInGCS
		$chart = $chartInGCS
		If ( $localRepoPath ) {
			$localPath = Convert-Path $localRepoPath
			Write-Host "gsutil -m rsync -d -r gs://$repo/$chart $localPath"
			gsutil -m rsync -d -r gs://$repoInGCS/$chartInGCS $localRepoPath
		}
		Else {
			$localPath = Join-Path $rootChartPath $repo $chart
			Write-Host "gsutil -m rsync -d -r gs://$repo/$chart $localPath"
			gsutil -m rsync -d -r gs://$repo/$chart $localRepoPath
		}
	}
}