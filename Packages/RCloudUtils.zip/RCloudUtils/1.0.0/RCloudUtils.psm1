if ( ! ([Kube]::relevantContainers | Where { $_ }) ) {
	[Kube]::relevantContainers = 'abacus','main', 'clickhouse','fileshare','rabbitmq', 'kubernetes-driver','kubernetes-executor', 'oracledb','monitor','file-loader-job'
}