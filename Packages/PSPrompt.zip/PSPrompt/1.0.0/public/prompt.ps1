function prompt {
    [PSPrompt]::GetPrompt()
}
    