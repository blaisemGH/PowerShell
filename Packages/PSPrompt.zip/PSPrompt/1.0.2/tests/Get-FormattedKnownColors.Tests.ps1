Describe 'Get-FormattedKnownColors' {
    It 'Gets "hello world" where known color equals Orchid' {}
}