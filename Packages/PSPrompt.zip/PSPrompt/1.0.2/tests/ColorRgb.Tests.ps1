Describe 'ColorRgb' {
    It 'tests TryParseString() with semicolon' {}
    It 'tests TryParseString() with hexcode' {}
    It 'tests TryParseString() with knowncolor' {}
    It 'tests ConvertColorRGBToAnsi()' {}
    It 'tests ConvertColorIntToHexCode() with integer input' {}
    It 'tests ConvertColorIntToHexCode() with 3 integer input' {}
    It 'tests ToString()' {}
}