Function Update-GCloudProjectFS {
    $currentProjects = Import-CSV ([GCloud]::PathToProjectCSV) -Delimiter ','
    $currentFSProjects = Get-ChildItem ([GCloud]::ProjectRoot) -Recurse -File | Select-Object -ExpandProperty Name

    Remove-OldGCloudProjectsFromLocalDrive -GCloudProjects $currentProjects -FilesystemProjects $currentFSProjects

    Add-MissingGCloudProjectsToLocalDrive -GCloudProjects $currentProjects -FilesystemProjects $currentFSProjects
}

# This function will recursively climb up the parent folders and remove any that are empty. Stops climbing at [GCloud]::ProjectRoot.
Function Remove-OldGCloudProjectsFromLocalDrive {
    param(
        [Parameter(Mandatory)]
        [PSCustomObject[]]$GCloudProjects,
        [string[]]$FilesystemProjects
    )
    $FilesystemProjects | Where-Object {
        $_ -notin $GCloudProjects.Project_ID
    } | ForEach-Object {

        Write-Host "Project ID $_ no longer found in GCloud. Deleting project from local filesystem cache..." -Fore Red

        Get-ChildItem ([GCloud]::ProjectRoot) -Recurse -File -Filter $_ | Select-Object -ExpandProperty FullName | ForEach-Object {
            Remove-OldProject -LocalFilePath $_ -RootPathEscapedRegex ([Regex]::Escape((Convert-Path ([GCloud]::ProjectRoot))))
        }
    }
}

Function Remove-OldProject {
    Param(
        [Parameter(Mandatory)]
        [string]$LocalFilePath,
        [Parameter(Mandatory)]
        [string]$RootPathEscapedRegex
    )
    Remove-Item -LiteralPath $LocalFilePath
    $parentDir = Split-Path $LocalFilePath -Parent

    # Perform 2 checks to determine if eligible for deletion:
        # 1) Remove the rootpath and see if there's any value leftover after trimming any . or dir separators.
            # This prevents the function from climbing up to or above the root path and deleting folders that should be kept.
        # 2) Check if the parent directory has empty contents.
            # This prevents the function from attempting to delete any directories that house other projects which still exist.
    if ( ($parentDir -replace $RootPathEscapedRegex).Trim('.' + [IO.Path]::DirectorySeparatorChar) -and
        -not (Get-ChildItem $parentDir)
    ) {
        Remove-OldProject -LocalFilePath $parentDir -RootPathEscapedRegex $RootPathEscapedRegex
    }
}

Function Add-MissingGCloudProjectsToLocalDrive {
    param(
        [Parameter(Mandatory)]
        [PSCustomObject[]]$GCloudProjects,
        [PSCustomObject[]]$FilesystemProjects
    )
    $GCloudProjects |
        Where-Object {
            $_.project_id -notin $FilesystemProjects -and
            $_.project_id -match ([GCloud]::FilterProjectIds) -and
            $_.name -match ([GCloud]::FilterProjectNames)            
        } |
        ForEach-Object {
            Write-Host "Found new project folder $($_.name). Fetching metadata..." -Fore Green
            $projectDriveFilePath = Get-GCloudProjectLineageAsFilepath -ProjectID $_.project_id

            if ( $projectDriveFilePath ) {
                Write-Host 'Adding new local filepath ' -Fore Magenta -NoNewLine; Write-Host $projectDriveFilePath
                $projectFullPath = Join-Path ([GCloud]::ProjectRoot) $projectDriveFilePath
                $null = New-Item  $projectFullPath -ItemType File -force
            }
            Write-Host '' # Add a space between logging outputs
        }
}

<# Notes on how the below function works
    For each project, there is a hierarchy of lineages obtained via gcloud get-ancestors. Each hierarchy is a folder in gcloud.
    We need to obtain their display names, i.e., folder names.
    For a single project id, the output of get-ancestors looks like this:
        ID                 TYPE
        --                 ----
        abc-0axk-rhji-v568 project
        387071328343       folder
        683520222268       folder
        0576461338171      folder
        862352227463       folder # Possible nested organization (still labeled here as folder by GCloud)
        385474470731       folder
        213350444167       organization
    We need to loop through each TYPE=folder and obtain the display name (folder name) via gcloud describe.
    If an organization number is defined in class [GCloud], we should stop at that ID number to avoid access errors on administrative tiers.
        This organization number is not necessarily TYPE=organization but could also be a folder as shown in the above example.
    At the end of the loop for a given project, join all the display names together. This is the folder path.
    The project ID comes from the describe of TYPE=type which outputs its parent (NOT given in the above hierarchy output) and the project ID.
        Therefore, the folder path must append the project parent and the project id. This is the "leaf" in the code above.
#>

Function Get-GCloudProjectLineageAsFilepath {
    Param(
        [Parameter(Mandatory)]    
        [string]$ProjectId
    )
    $projectLineage = (gcloud projects get-ancestors $ProjectId) -replace
        '\s{2,}', [char]0x2561 |
        ConvertFrom-Csv -Delimiter ([char]0x2561)

    $folderNames = foreach ( $folder in ($projectLineage | where TYPE -eq folder) ){
        # Stop at the designated organization ID. This prevents permission errors for tiers above this.        
        if ( $folder.ID -eq [GCloud]::OrganizationNumber ) { 
            break
        }

        gcloud resource-manager folders describe $folder.ID --format json | 
            ConvertFrom-Json | 
            Select-Object -ExpandProperty DisplayName
    }
    [Array]::Reverse($folderNames) # reverse so the -join below in $childPath orders ascending to descending in the folder hierarchy.

    # Get the project type's display name and its parent's display name. These will be appended to the end of the final path.
    $projectID = $projectLineage | Where-Object type -eq 'project' | Select-Object -ExpandProperty id
    $ProjectLeafItem = gcloud projects describe $projectID --format json | ConvertFrom-Json

    # Express parent folders and leaf items as local filepaths
    $parentPath = $folderNames -join '/'
    $leafPath = Join-Path $ProjectLeafItem.name $ProjectLeafItem.projectId

    # Remove whitespace around hyphens to make later filesystem navigation more convenient.
    return (Join-Path $parentPath $leafPath) -replace '(?<=-)\s|\s(?=-)' -replace '\s', '-'
}