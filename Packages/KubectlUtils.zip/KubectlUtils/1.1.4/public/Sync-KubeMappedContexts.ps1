function Sync-KubeMappedContexts {
    [Kube]::UpdateKubeMappedContexts()
}