Class ViewNodesByPod {
	[string]$PodCount
	[string]$NodeType
	[string]$CoresAndMem
	[string]$Pods
	hidden [string]$NodeName
}