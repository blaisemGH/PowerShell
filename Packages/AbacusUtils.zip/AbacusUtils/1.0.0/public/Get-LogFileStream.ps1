### A PowerShell-adapted analog to the Bash "tail -f" command.
Function Get-LogFileStream {
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true,position=0,ValueFromPipeline=$true)]
		$fileToTail
	)

	If ( !( Test-Path ( $fileToTail + '.log' )) -and ($fileToTail -NotMatch '/' -and $fileToTail -NotMatch '\\' ) ) {
		$logFile = ( $fileToTail + '.log' )
		$tailFile = Get-ChildItem logs/* -Recurse -File -Filter $logFile | Select-Object -ExpandProperty FullName -First 1
		If ( !$tailFile -and $fileToTail -match 'server') {
			$tailFile = Get-ChildItem wildfly/standalone -Recurse -File -Filter $logFile | Select-Object -ExpandProperty FullName -First 1
		}
		If ( !$tailFile ) {
			Throw "$fileToTail not found!"
		}
		Else {
			Get-Content $tailFile -Wait -Tail 100
		}
	}
	ElseIf ( ! ( Test-Path $fileToTail ) ) {
		Throw "$fileToTail not found!"
	}
	Else {
		Get-Content $fileToTail -wait -tail 100
	}
}
