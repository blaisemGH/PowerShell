Function Replace-StringInFunctionalUnit {
	Param(
		[Parameter(ValueFromPipeline,Mandatory)]
		[string]$fu,
		[Parameter(Mandatory)]
		[string]$replace
	)
	begin {
		$out = [List[string]]@()
	}
	process {		
		$unit = $fu -split "\n"
		$unit | % {
			if ( $_ -match "$replace[.]" ) {
				Select-String -InputObject $_ -Pattern "$replace[.]([^\s,]+)" -AllMatches | select -exp matches | select -exp groups | ? Name -eq 1 | select -exp value | % {
					$out.Add($_ -replace '\).*' -replace '.*\(' )
				}
			}
		}
	}
	end {
		$out | sort -Unique | % { '        ' + "$replace." + $_ + ',' }
	}
}