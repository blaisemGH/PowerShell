function Select-SqlxProcessLogFUDurations {
	param(
		[parameter(mandatory)]
		[ArgumentCompleter({
			Param( $commandName, $parameterName, $wordToComplete, $commandAst, $fakeBoundParameters )
			Get-ChildItem $wordToComplete* -Filter *sqlx*.log | Resolve-Path -Relative
		})]
		[Alias('logSqlx')]
		[string]$SqlxProcessLogFilePath,
		[string]$FunctionalUnit,
		[string]$Component,
		[switch]$autoFormat
	)

	$regexFunctionalUnit = If (!$FunctionalUnit) {
		'.*'
	} Else { $FunctionalUnit }

	$regexComponent = If (!$Component) {
		'.*'
	} Else { $Component }

	$paramsSelectString = @{
		'Path' = Convert-Path $SqlxProcessLogFilePath
		'Pattern' = [regex]::new("Finished Unit '(?<functional_unit>$regexFunctionalUnit)' \((?<unit_number>[0-9]+/[0-9]+)\).* Component '(?<component>$regexComponent)' \((?<component_number>[0-9]+/[0-9]+)\) - (?<duration>[0-9:.]+)$", 'Compiled, CultureInvariant' )
	}
	
	$tempOut = Select-String @paramsSelectString |
		Select-Object @{
			'label' = 'Duration'
			'expression' = { [Timespan]::ParseExact($_.Matches.Groups[5].Value , 'hh\:mm\:ss\.fff', $null) }
		}, @{
			'label' = 'Functional Unit'
			'expression' = { $_.Matches.Groups[1].Value }
		}, @{
			'label' = 'Component'
			'expression' = { $_.Matches.Groups[2].Value }
		}, @{
			'label' = 'unit_number'
			'expression' = { $_.Matches.Groups[3].Value }
		}, @{
			'label' = 'component_number'
			'expression' = { $_.Matches.Groups[4].Value }
		}

	If ( $autoFormat ) {
		$tempOut | Sort Duration | Format-Table -Autosize -Wrap
	}
	Else {
		$tempOut
	}
}