### Compares your current properties to the installation template files.
Function diffProps {

	If ( ! ( Test-Path $PWD/custom/properties ) ) { 
		Throw 'Please cd into an ABACUS_HOME directory'
	}

	$OldPropertyDirectory = ("$PWD"+"\install\config\properties")
	$NewPropertyDirectory = ("$PWD"+"\custom\properties")

	$propertiesFilesList = @()
	Get-ChildItem $OldPropertyDirectory\*.properties | ForEach {
		$propertiesFilesList += ( Split-Path $_ -leaf -resolve ).split('.')[0] 
	}


	ForEach ($i in $propertiesFilesList) {
		Write-Host "$i.properties" -ForegroundColor yellow
		$output = Compare-Object (Get-Content $OldPropertyDirectory\$i.properties | ForEach-Object -begin { $ln1=0 } -process { '{0,6}<<:{1}' -f ++$ln1,$_ }) (Get-Content $NewPropertyDirectory\$i.properties | ForEach-Object -begin { $ln2=0 } -process { '{0,6}>>:{1}' -f ++$ln2,$_ }) -property { $_.substring(9) } -passthru | Sort-Object | Out-String -width 200
		If ($Args[1]) {
			(( $output | Out-String) -split ([Env]::NL) | Select-String -Pattern $Args[1] -context 0,1 | Out-String ) -split ([Env]::NL) | Select-String -pattern '###EDITED On' -notmatch 
		}
		Else {
			( $output | Out-String) -split ([Env]::NL) | Select-String -pattern '###EDITED On' -notmatch
		}
	}
}