class KubeNodesByPod {
    [string]$PodCount
    [string]$NodeType
    [string]$CoresAndMem
    [string]$Pods
    [string]$NodeName
}
