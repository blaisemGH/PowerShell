enum GcpConsoleArea {
    ArtifactRegistry
    ComputeDisks
    ComputeInstances
    ComputeSnapshots
    Kubernetes
    Iam
    IamQuotas
    PamEntitlements
    StorageBuckets
    SupportCases
    Welcome
}